let mix = require('laravel-mix');

mix.ts('src/script.ts', 'dist').setPublicPath('dist');
